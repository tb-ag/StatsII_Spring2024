
df = readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) 

m = tjbal(df, Y = 'recruit_bn', 
               D = "treat", 
               index = c("DISTID", "year"), 
               demean = F, 
               estimator = 'mean', 
               vce = 'jack')
recruit_bin_plot = make_tj_ct(m, 'Years until Courts', 'Recruitment (Binary)', '') + theme_tufte() + 
  theme(legend.position = 'bottom')
ggsave('fig-out/recruit_bin_plot.pdf')

m = tjbal(df, Y = 'recruit', 
          D = "treat", 
          index = c("DISTID", "year"), 
          demean = F, 
          estimator = 'mean', 
          vce = 'jack')
recruit_lvl_plot = make_tj_ct(m, 'Years until Courts', 'Recruitment (Count)', '') + theme_tufte() + 
  theme(legend.position = 'bottom')
ggsave('fig-out/recruit_lvl_plot.pdf')
