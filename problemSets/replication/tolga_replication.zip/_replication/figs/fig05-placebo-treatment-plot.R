
balance_panel_df = readRDS('DATA/balance_panel_df.rds')

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year < 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) %>% 
  select('DISTID', 'year', 'cohort', 'treat', 
         'aog', 'IED_Explosion', 'DF', 'ied', 
         'totalcas', 'treated_ever'
  ) 
anqar_panel = readRDS('data/anqar_panel_2023.rds') %>% 
  filter(year <= 2014)

df = merge(df, anqar_panel, by = c('DISTID', 'year'), all.x = T)

df = merge(df, balance_panel_df, by = c('DISTID', 'year'), all.x = T)

df = df %>%  
  mutate_at(c('aog', 'IED_Explosion', 'DF', 'ied', 
              'totalcas', 'dispute_court',
              'gov_influence', 'gov_index2', 
              'return_good', 'dispute_court', 
              'op_fit1_stdXlnpyear', 'ipop', 
              'n_fob', 'temp_shock', 'rain_shock', 
              'ntl.sum','wheat_shock'
  ), scale)

placebo_data = df %>% 
  filter(year < 2011) %>% 
  mutate(
    placebo_treat_10 = as.numeric(treated_ever ==1  & year >= 2010, 1,0)
  ) %>% 
  as.data.frame()

placebo_data = placebo_data %>%  
  select('aog', 'IED_Explosion', 'DF', 'ied', 
         'totalcas',  
         'op_fit1_stdXlnpyear', 
         'ntl.sum', 'ipop', 'n_fob', 
         'temp_shock',  'rain_shock', 'wheat_shock', 
         'placebo_treat_10', 'DISTID', 'year')

J <- 12
att_tjbal <- matrix(, nrow = J, ncol = 3)
out_names <- names(placebo_data)[1:J]
out_names

for(j in 1:J){
  
  att_tjbal[j, 1:3] <- print(tjbal(data = placebo_data, 
                                   Y = out_names[j], 
                                   D = "placebo_treat_10", 
                                   index = c("DISTID", "year"), 
                                   demean = F, estimator = "mean", 
                                   vce = "jackknife"))[c(1,2,6)]
}

colnames(att_tjbal)[1:3] = c('att', 'se', 'pval')


#### 2011 placebo #### 

placebo_data = df %>% 
  filter(year < 2012) %>% 
  filter(cohort != 2011) %>% 
  mutate(
    placebo_treat_10 = as.numeric(treated_ever ==1  & year >= 2011, 1,0)
  ) %>% 
  as.data.frame()

placebo_data = placebo_data %>%  
  select('aog', 'IED_Explosion', 'DF', 'ied', 
         'totalcas',  
         'op_fit1_stdXlnpyear', 
         'ntl.sum', 'ipop', 'n_fob', 
         'temp_shock',  'rain_shock', 'wheat_shock', 
         'placebo_treat_10', 'DISTID', 'year')

J <- 12
att_tjbal2 <- matrix(, nrow = J, ncol = 3)
out_names <- names(placebo_data)[1:J]
out_names

for(j in 1:J){
  
  att_tjbal2[j, 1:3] <- print(tjbal(data = placebo_data, 
                                   Y = out_names[j], 
                                   D = "placebo_treat_10", 
                                   index = c("DISTID", "year"), 
                                   demean = F, estimator = "mean", 
                                   vce = "jackknife"))[c(1,2,6)]
}

colnames(att_tjbal2)[1:3] = c('att', 'se', 'pval')



##### attitudes #### 

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year < 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) %>% 
  select('DISTID', 'year', 'cohort', 'treat', 'treated_ever'
  ) 
anqar_panel = readRDS('data/anqar_panel_2023.rds') %>% 
  filter(year <= 2014)
df = merge(df, anqar_panel, by = c('DISTID', 'year'), all.x = T)

df_balance <- df %>% 
  group_by(DISTID) %>% 
  filter(year >= 2009) %>% 
  mutate(na_ever = mean(return_good)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year <= 2011) %>% 
  filter(cohort != 2011) %>% 
  mutate(
    placebo_treat_10 = as.numeric(treated_ever ==1  & year >= 2011, 1,0), 
    return_good = scale(return_good)
    
  ) %>% 
  as.data.frame()

m_return_plac = tjbal(data = df_balance, Y = 'return_good', 
                      D = "placebo_treat_10", 
                      index = c("DISTID", "year"), 
                      demean = F, estimator = "mean", 
                      vce = "jackknife")

df_balance <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2009) %>% 
  filter(year < 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )  %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(dispute_court)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year <= 2011) %>% 
  filter(cohort != 2011) %>% 
  mutate(
    placebo_treat_10 = as.numeric(treated_ever ==1  & year >= 2011, 1,0), 
    dispute_court = scale(dispute_court)
    
  ) %>% 
  as.data.frame()

m_dispute_court_plac = tjbal(data = df_balance, Y = 'dispute_court', 
                             D = "placebo_treat_10", 
                             index = c("DISTID", "year"), 
                             demean = F, estimator = "mean", 
                             vce = "jackknife")

df2 = df %>% 
  select('year', 'DISTID', 'treated_ever', 'cohort')

anqar_panel = readRDS('DATA/anqar_panel_2023.rds')

df2 = merge(df2, anqar_panel, by = c('DISTID', 'year'), 
            all.x = TRUE 
)

df3 = df2 %>% 
  group_by(DISTID) %>% 
  filter(year >= 2008) %>%
  mutate(na_ever = mean(gov_index2)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year < 2011) %>% 
  mutate(
    placebo_treat = as.numeric(treated_ever ==1  & year >= 2010, 1,0), 
    gov_index2 = scale(gov_index2)
  ) %>% 
  as.data.frame()

m_inf_2010 = tjbal(data = df3, Y = 'gov_index2', 
                   D = "placebo_treat", 
                   index = c("DISTID", "year"), 
                   demean = F, estimator = "mean", 
                   vce = "jack")

df3 = df2 %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(gov_influence)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year < 2011) %>% 
  mutate(
    placebo_treat = as.numeric(treated_ever ==1  & year >= 2010, 1,0), 
    gov_influence = scale(gov_influence)
  ) %>% 
  filter(DISTID != '3205') %>% 
  as.data.frame()

m_cnt_2010 = tjbal(data = df3, Y = 'gov_influence', 
                   D = "placebo_treat", 
                   index = c("DISTID", "year"), 
                   demean = F, estimator = "mean", 
                   vce = "jack")

df3 = df2 %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(gov_index2)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year <= 2011) %>% 
  filter(cohort != 2011) %>% 
  mutate(
    placebo_treat = as.numeric(treated_ever == 1  & year >= 2011, 1,0), 
    gov_index2 = scale(gov_index2)
  ) %>% 
  as.data.frame()

m_inf_2011 = tjbal(data = df3, Y = 'gov_index2', 
                   D = "placebo_treat", 
                   index = c("DISTID", "year"), 
                   demean = F, estimator = "mean", 
                   vce = "jack")

df3 = df2 %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(gov_influence)) %>% 
  filter(is.na(na_ever) == F) %>% 
  filter(year <= 2011) %>% 
  filter(cohort != 2011) %>% 
  mutate(
    placebo_treat = as.numeric(treated_ever ==1  & year >= 2011, 1,0), 
    gov_influence = scale(gov_influence)
  ) %>% 
  filter(DISTID != '3205') %>% 
  as.data.frame()

m_cnt_2011 = tjbal(data = df3, Y = 'gov_influence', 
                   D = "placebo_treat", 
                   index = c("DISTID", "year"), 
                   demean = F, estimator = "mean", 
                   vce = "jack")

att_attitude = rbind.data.frame(
  print(m_cnt_2011)[c(1,2,6)], 
  print(m_cnt_2010)[c(1,2,6)], 
  print(m_inf_2010)[c(1,2,6)], 
  print(m_inf_2011)[c(1,2,6)], 
  print(m_return_plac)[c(1,2,6)],
  print(m_dispute_court_plac)[c(1,2,6)]
  
)
colnames(att_attitude)[1:3] = c('att', 'se', 'pval')

att_attitude$placebo_year = c('2011', '2010', 
                              '2010', '2011', 
                              '2011', '2011'
                              )
att_tjbal = cbind.data.frame(att_tjbal, placebo_year =  c(rep('2010', 12))) 
att_tjbal2 = cbind.data.frame(att_tjbal2, placebo_year =  c(rep('2011', 12))) 


att_full = rbind.data.frame(
  att_attitude, 
  att_tjbal, 
  att_tjbal2
)

att_full$est_name = NA 
att_full$est_name[att_full$att == -0.1807] = 'Rain Shock'
att_full$est_name[att_full$att == 0.1226] = 'Opium Shock'

balance_plot = ggplot(att_full, aes(pval, att, 
                     shape = factor(placebo_year),
                     label = est_name
                     )) + 
  geom_point(size = 3) + 
  geom_hline(yintercept = 0, col = 'red') + 
  geom_vline(xintercept = .05, col = 'red', lty = 2) + 
  scale_shape_discrete(name = 'Placebo Year') + 
  xlab('P-value') + 
  ylab('ATT') + 
  geom_rect(aes(xmin=.05, xmax=Inf, ymin=-Inf, ymax=Inf), alpha = .01) + 
  geom_label_repel(box.padding = 0.5) +
  theme_tufte() + 
  geom_label(aes(x = .6, y = max(att)-.01, 
                 label = 'Shaded Region: Fail to Reject the Null \nat .05 Level')) + 
  theme(legend.position = 'bottom') 


ggsave('fig-out/placebo_plot.pdf', width = 6, height = 4.5)




