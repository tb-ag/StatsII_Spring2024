getwd()
source('_pgks.R')
install.packages(c("ggplot2", "readstata13", "dplyr", "stats", "base", 
                   "ggthemes", "tjbal", "tmap", "sf", "ggrepel", "xtable",
                   "tidyr", "lfe", "magrittr", "countrycode"))
devtools::install_github("chadhazlett/KBAL")
devtools::install_github("xuyiqing/tjbal")
source('_funs.R')
lapply(c("ggplot2", "readstata13", "dplyr", "stats", "base", 
         "ggthemes", "tjbal", "tmap", "sf", "ggrepel", "xtable",
         "tidyr", "lfe", "magrittr", "devtools", "kbal", "tjbal"), require, character.only = TRUE)
list.files("figs", full.names = TRUE) %>% purrr::walk(source)
beepr::beep(sound = 3)
list.files("tabs", full.names = TRUE) %>% purrr::walk(source)
beepr::beep(sound = 3)
warnings()
source()