

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2013) %>% 
  filter(cohort == '10000' | cohort == '2013' | cohort == '2011' | cohort == '2012') %>%  
  mutate(
    cohort = ifelse(cohort == '10000', '0', cohort), 
    lndispute = log(dispute+1), 
    dispute_bin = as.numeric(dispute > 0, 1, 0), 
    lnlanddispute = log(land_dispute+1), 
    land_dispute_bin = as.numeric(land_dispute>0,1,0), 
    lncrime = log(crime+1), 
    crime_bin = as.numeric(crime>0,1,0), 
    treat = ifelse(cohort != '0', as.numeric(year >= as.numeric(cohort), 1,0), 0)
  ) 

df2 <- df[ ,c('lndispute', 'dispute_bin', 'lnlanddispute', "land_dispute_bin", 
              "lncrime", 'crime_bin',
              'treat', 'DISTID', 'year', 'cohort')]
J <- 6

att_tjbal <- matrix(, nrow = J, ncol = 3)
out_names <- names(df2)[1:J]


for(j in 1:J){
  
  att_tjbal[j, 1:3] <- print(tjbal(data = df2, Y = out_names[j], D = "treat", 
                                   index = c("DISTID", "year"), demean = F, estimator = "mean", 
                                   vce = "jackknife"))[c(1,2,6)]
  
}

att_tjbal <- as.data.frame(att_tjbal)
att_tjbal$outcome_name <- out_names[1:J]
colnames(att_tjbal)[1:3] <- c('att', 'se', 'pval')
att_tjbal <- att_tjbal %>% 
  mutate(att = ifelse(pval < .05, paste0(att, "*"), att), 
         att = ifelse(pval < .01, paste0(att, "*"), att), 
         att = ifelse(pval < .001, paste0(att, "*"), att), 
  ) %>% 
  mutate_if(is.numeric, as.character)




att_tjbal <- att_tjbal %>% 
  pivot_longer(cols = c('att', 'se', 'pval'))

att_tjbal <- att_tjbal %>% 
  pivot_wider(names_from = outcome_name, 
              values_from = value)

colnames(att_tjbal)[2:(J+1)] <- c('ln(Dispute+1)', '1(Dispute)', 
                                  'ln(Property Dispute+1)', '1(Property Dispute)', 
                                  'ln(Crime)', '1(Crime)'
)
att_tjbal <- rbind.data.frame(att_tjbal,
                              dataset = c("ANSO", 'ANSO', 'ANSO', 'ANSO', 
                                          'ANSO', 'ANSO'), 
                              Districts  = c("N. Districts", rep(rep(length(unique(df$DISTID)), J))),
                              Years  = c("N. Years", rep(rep(length(unique(df$year)), J))),
                              Stdev  = c("Standard Deviation DV", 
                                         round(sd(df$lndispute),2), round(sd(df$dispute_bin),2), 
                                         round(sd(df$lnlanddispute),2), 
                                         round(sd(df$land_dispute_bin),2), 
                                         round(sd(df$lncrime),2), 
                                         round(sd(df$crime_bin),2)),
                              MeanDV  = c("Mean DV (Control)", 
                                          round(mean(df$lndispute[df$treated_ever==0]),2), 
                                          round(mean(df$dispute_bin[df$treated_ever==0]),2 ), 
                                          round(mean(df$lnlanddispute[df$treated_ever==0]),2), 
                                          round(mean(df$land_dispute_bin[df$treated_ever==0]),2), 
                                          round(mean(df$lncrime[df$treated_ever==0]),2), 
                                          round(mean(df$crime_bin[df$treated_ever==0]),2))
)

print.xtable(xtable(att_tjbal), booktabs = T,  include.rownames = F, file = 'tables/social_conflict_table.tex')

n_obs = length(unique(df$year))*rep(length(unique(df$DISTID)))
                                    