##### Conflict Outcomes Table #### 

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year < 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) %>% 
  dplyr::select('aog_no_ied', 'ied', "DF", 
                "IED_Explosion", 'totalcas',
                'treat', 'DISTID', 'year', 'cohort', 'treated_ever')

J <- 5

att_tjbal <- matrix(, nrow = J, ncol = 3)
out_names <- names(df)[1:J]


for(j in 1:J){
  
  att_tjbal[j, 1:3] <- print(tjbal(data = df, Y = out_names[j], D = "treat", 
                                   index = c("DISTID", "year"), 
                                   demean = F, estimator = "mean", 
                                   vce = "jackknife"))[c(1,2,6)]
  
}

make_tjbal_table(att_tjbal, 2, 1, out_names = c('AOG', 'IED', "DF", 
                                                "IED Explosions", 'Causality Events'), 
                 data = df, id = df$DISTID, 
                 time = df$year, treated_group = df$treated_ever, 
                 outcome_matrix = df[,1:5], header = FALSE, header_labels = NA, 
                 label_treatment = 'Taliban Courts', extra_arg = c('Dataset', 
                                                                   rep('ANSO', 2), 
                                                                   rep('SIGACT', 3)),
                 file_save = paste0(getwd(), "//tables", "//combat_table.tex")
)