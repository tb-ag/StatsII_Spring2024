
test = cbind.data.frame(
Assumptions = c('Conditional Ignorability', 'LPO', 'Weights'), 
`Observable Implications` = c('Y', '-', 'Y'), 
Tests = c('Placebo Test', '-', 'Trend Plots' ), 
Relaxable = c('Y', 'Y', "-"), 
Relaxation = c('Covariates', 'Kernel Balancing', "-")
)

print.xtable(test, file = 'tables/assump_mat.tex')
