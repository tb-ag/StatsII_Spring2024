
balance_panel_df = readRDS('data/balance_panel_df.rds')

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) %>% 
  select('DISTID', 'year', 'cohort', 'treat', 
         'aog_no_ied', 'IED_Explosion', 'DF', 'ied', 
         'totalcas', 'treated_ever'
  ) 
  
anqar_panel = readRDS('data/anqar_panel_2023.rds') %>% 
  filter(year <= 2014)
df = merge(df, anqar_panel, by = c('DISTID', 'year'), all.x = T)
df = merge(df, balance_panel_df, by = c('DISTID', 'year'), all.x = T)

control = read.dta13('data/enumerability/DISTID_cross_section.dta')

df = merge(df,control, by = 'DISTID', all.x = T)
df = df %>% 
  mutate(
    contested = as.numeric(not_accessible_taliban < 1 &
                             not_accessible_taliban != 0,1,0), 
    controlled = as.numeric(not_accessible_taliban == 1, 1,0)
  )
#df$not_accessible_taliban[is.na(df$not_accessible_taliban)] = 0 

df  = df %>% 
  group_by(DISTID) %>% 
  mutate(rain_mean = mean(rain_shock, na.rm = T), 
         opium = mean(op_fit1_stdXlnpyear, na.rm = T)) %>% 
  filter(is.na(not_accessible_taliban) == F)  %>% 
  as.data.frame()



#### Combat #### 
df2 = df %>% 
  dplyr::select('aog_no_ied', 'ied', "DF", 
                "IED_Explosion", 'totalcas',
                'treat', 'DISTID', 'year', 
                'cohort', 'treated_ever', 
                'rain_mean', 'opium', 'not_accessible_taliban')
J <- 5
out_names <- names(df2)[1:J]




att_tjbal <- matrix(, nrow = J, ncol = 3)

df3 = df2 %>% 
  filter(year < 2014) %>% 
  dplyr::select('aog_no_ied', 'ied', "DF", 
                "IED_Explosion", 'totalcas',
                'treat', 'DISTID', 'year', 
                'cohort', 'treated_ever', 
                'rain_mean', 'opium', 'not_accessible_taliban') %>% 
  filter(is.na(not_accessible_taliban) == F) %>% 
  as.data.frame()

for(j in 1:J){
  
  att_tjbal[j, 1:3] <- print(tjbal(data = df3, Y = out_names[j], D = "treat", 
                                   index = c("DISTID", "year"), 
                                   X = c('not_accessible_taliban', 
                                         'rain_mean', 
                                         'opium'
                                         ),
                                   demean = F, estimator = "mean", 
                                   vce = "jackknife"))[c(1,2,6)]
  
}

make_tjbal_table(att_tjbal, 2, 1, out_names = c('AOG', 'IED', "DF", 
                                                "IED Explosions", 'Causality Events'), 
                 data = df3, id = df3$DISTID, 
                 time = df3$year, treated_group = df3$treated_ever, 
                 outcome_matrix = df3[,1:5], header = FALSE, header_labels = NA, 
                 label_treatment = 'Taliban Courts', extra_arg = c('Dataset', 
                                                                   rep('ANSO', 2), 
                                                                   rep('SIGACT', 3)),
                 file_save = paste0(getwd(), "//tables", "//combat_table_controls.tex")
)


out1 = tjbal_unbalance(data = df, outcome = df$return_good, 
                baseline_year = 2009, 
                X = c('not_accessible_taliban', 
                      'rain_mean', 
                      'opium'
                ),
     estimator_type = "mean", 
     vce = "jackknife")

out2 = tjbal_unbalance(data = df, outcome = df$dispute_court, 
                       baseline_year = 2009, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "mean", 
                       vce = "jackknife")

out3 = tjbal_unbalance(data = df, outcome = df$gov_influence, 
                       baseline_year = 2008, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "mean", 
                       vce = "jackknife")

out4 = tjbal_unbalance(data = df, outcome = df$gov_index2, 
                       baseline_year = 2008, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "mean", 
                       vce = "jackknife")

att_tjbal_opinion <- matrix(, nrow = 4, ncol = 3)
out_list = rbind.data.frame(mod_1 = print(out1), mod_2 = print(out2), 
                            mod_3 = print(out3), mod_4 = print(out4))
out_list = out_list[ ,c(1,2,6)]

make_tjbal_table(out_list, 2, 1, out_names = c('State Court', 'Taliban Approval', 
                                               "Gov. Influence", 
                                               "Gov. Index"), 
                 data = df3, id = df3$DISTID, 
                 time = df3$year, treated_group = df3$treated_ever, 
                 outcome_matrix = df3[,1:5], header = FALSE, header_labels = NA, 
                 label_treatment = 'Taliban Courts', extra_arg = NULL,
                 file_save = paste0(getwd(), "//tables", "//opinion_table_controls_mean.tex")
)


##### Kernel Version #### 
att_tjbal <- matrix(, nrow = J, ncol = 3)

for(j in 1:J){
  
  att_tjbal[j, 1:3] <- print(tjbal(data = df3, Y = out_names[j], D = "treat", 
                                   index = c("DISTID", "year"), 
                                   X = c('not_accessible_taliban', 
                                         'rain_mean', 
                                         'opium'
                                   ),
                                   demean = F, estimator = "kernel", 
                                   vce = "jackknife"))[c(1,2,6)]
  
}

make_tjbal_table(att_tjbal, 2, 1, out_names = c('AOG', 'IED', "DF", 
                                                "IED Explosions", 'Causality Events'), 
                 data = df3, id = df3$DISTID, 
                 time = df3$year, treated_group = df3$treated_ever, 
                 outcome_matrix = df3[,1:5], header = FALSE, header_labels = NA, 
                 label_treatment = 'Taliban Courts', extra_arg = c('Dataset', 
                                                                   rep('ANSO', 2), 
                                                                   rep('SIGACT', 3)),
                 file_save = paste0(getwd(), "//tables", "//combat_table_controls_kernel.tex")
)


out1 = tjbal_unbalance(data = df, outcome = df$dispute_court, 
                       baseline_year = 2009, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "kernel", 
                       vce = "jackknife")

out2 = tjbal_unbalance(data = df, outcome = df$return_good, 
                       baseline_year = 2009, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "kernel", 
                       vce = "jackknife")

out3 = tjbal_unbalance(data = df, outcome = df$gov_influence, 
                       baseline_year = 2008, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "kernel", 
                       vce = "jackknife")

out4 = tjbal_unbalance(data = df, outcome = df$gov_index2, 
                       baseline_year = 2008, 
                       X = c('not_accessible_taliban', 
                             'rain_mean', 
                             'opium'
                       ),
                       estimator_type = "kernel", 
                       vce = "jackknife")

att_tjbal_opinion <- matrix(, nrow = 4, ncol = 3)
out_list = rbind.data.frame(mod_1 = print(out1), mod_2 = print(out2), 
                 mod_3 = print(out3), mod_4 = print(out4))
out_list = out_list[ ,c(1,2,6)]

make_tjbal_table(out_list, 2, 1, out_names = c('State Court', 'Taliban Approval', 
                                               "Gov. Influence", 
                                                "Gov. Index"), 
                 data = df3, id = df3$DISTID, 
                 time = df3$year, treated_group = df3$treated_ever, 
                 outcome_matrix = df3[,1:5], header = FALSE, header_labels = NA, 
                 label_treatment = 'Taliban Courts', extra_arg = NULL,
                 file_save = paste0(getwd(), "//tables", "//opinion_table_controls_kernel.tex")
)
