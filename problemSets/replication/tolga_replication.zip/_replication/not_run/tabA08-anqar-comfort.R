
anqar <- read.dta13("data/ANQAR_ALL.dta") %>% 
  filter(Comfort == 'Comfortable With All')

anqar_comfort = anqar %>% 
  filter(Comfort == 'Comfortable With All') %>% 
  mutate(
    gov_influence = as.numeric(Q176 == "Government (District, Provincial, Police, etc.)", 
                               1,0 ), 
    return_good = as.numeric(Q178 == 'Good for the people and the country', 1,0), 
    
    dispute_court = as.numeric(Q312=="To an Afghanistan state court", 1,0), 
    
    
    prov_perform_security <- recodr(x = Q202),
    prov_perform_econ <- recodr(Q203),
    perform_perform_dev <- recodr(Q204),
    prov_perform_corrupt <- recodr(Q205),
    prov_perform_overall <- recodr(Q206),
    
    perform_overall <- recodr(Q189),
    perform_security <- recodr(Q190),
    perform_econ <- recodr(Q191),
    perform_construct <- recodr(Q192),
    perform_corrupt <- recodr(Q193),
    
    dis_perform_overall <- recodr(Q195),
    dis_perform_security <- recodr(Q196),
    dis_perform_econ <- recodr(Q197),
    dis_perform_construct <- recodr(Q198),
    dis_perform_corrupt <- recodr(Q199)
    
  )

anqar_pc_df <- anqar_comfort %>% 
  select(contains("perform_"), 'DISTID', 'year') %>% 
  na.omit()

anqar_pc_df$scores <- princomp(anqar_pc_df[1:15])$scores[,1]
anqar_gov_index_df <- anqar_pc_df %>% 
  group_by(DISTID, year) %>% 
  summarise(gov_index_total = mean(scores))

anqar_comfort = anqar_comfort %>% 
  group_by(DISTID, year) %>% 
  summarise(gov_influence = mean(gov_influence, na.rm = T), 
            return_good = mean(return_good, na.rm = T), 
            dispute_court = mean(dispute_court, na.rm = T)
            )

anqar_comfort = merge(anqar_comfort, anqar_gov_index_df, 
                      by = c('DISTID', 'year'), 
                      all.x = T
                      )
anqar_comfort = anqar_comfort %>% 
  filter(year >= 2008 & year <= 2014)




df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  select('DISTID', 'year', 'treated_ever', 'cohort') %>% 
  mutate(
    treated = ifelse(treated_ever, as.numeric(year >= cohort, 1,0), 0)
  )
df = merge(df, anqar_comfort, by = c("DISTID", 'year'), 
           all.x = T) 

return_df = df %>% 
  filter(year > 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(return_good)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

use_df = df %>% 
  filter(year > 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(dispute_court)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

control_df = df %>% 
  filter(year >= 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(gov_influence)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

gov_df = df %>% 
  filter(year >= 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(gov_index_total)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()


out1 <- tjbal(data = use_df, Y = "dispute_court", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out2 <- tjbal(data = return_df, Y = "return_good", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out3 <- tjbal(data = control_df, Y = "gov_influence", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out4 <- tjbal(data = gov_df, Y = "gov_index_total", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")

outcome_table = cbind.data.frame(
  'State Court' =  print(out1)[c(1,2,6)],
  'Taliban Approval' =  print(out2)[c(1,2,6)],
  'Gov. Influence' =  print(out3)[c(1,2,6)],
  'Gov. Index' = print(out4)[c(1,2,6)]
)

outcome_table = rbind.data.frame(outcome_table, 
                                 'N. District' = c(
                                   length(unique(use_df$DISTID)), 
                                   length(unique(return_df$DISTID)), 
                                   length(unique(control_df$DISTID)), 
                                   length(unique(gov_df$DISTID))
                                 ),
                                 'N. Year' = c('6', '6', '7', '7'), 
                                 'Sd. DV' = 
                                   c(round(sd(use_df$dispute_court),2), 
                                     round(sd(return_df$return_good), 2), 
                                     round(sd(control_df$gov_influence), 2), 
                                     round(sd(gov_df$gov_index_total), 2)),
                                 'Mean DV' = 
                                   c(round(mean(use_df$dispute_court),2), 
                                     round(mean(return_df$return_good), 2), 
                                     round(mean(control_df$gov_influence), 2), 
                                     round(mean(gov_df$gov_index_total), 2)
                                   ))

print.xtable(xtable(outcome_table), booktabs = T, include.rownames = F, 
             file = 'tables/anqar_comfort.tex')
