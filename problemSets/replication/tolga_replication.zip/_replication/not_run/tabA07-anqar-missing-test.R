
#### Packages, Working Directory, Theme Set #### 
anqar <- read.dta13("data/ANQAR_ALL.dta") %>% 
  filter(Wave <= 24) 

#Q176: Between the two, the Anti- Government Elements (Mukhalafeen-e dawlat) and the Government, who has more influence in your mantaqa now?

anqar$gov_influence <- as.numeric(anqar$Q176 == "Government (District, Provincial, Police, etc.)", 1,0 )
anqar$neither <- as.numeric(anqar$Q176 == "Neither", 1,0 )
anqar$influence_lvl = NA 
anqar$influence_lvl[anqar$Q176 == "Government (District, Provincial, Police, etc.)"] = 1
anqar$influence_lvl[anqar$Q176 == "Neither"] = 0
anqar$influence_lvl[anqar$Q176 == "AGE (mukhalfeen-e dawlat, dushman-e dawlat)"] = -1

anqar$influence_NA = as.numeric(is.na(anqar$influence_lvl) == TRUE, 1,0)

#Q178: 
#"In your opinion, if the Taliban were to return to power and govern Afghanistan, would it be a good thing for the people and the country, or would it be a bad thing for the people and the country?"

anqar$return_good <- as.numeric(anqar$Q178=="Good for the people and the country", 1,0)
anqar$return_good[anqar$Q178=="Refused"] <- NA
anqar$return_good[anqar$Q178=="Don't Know"] <- NA
anqar$return_good[is.na(anqar$Q178)] <- NA

#Q312
# Had a dispute, where do you go 

anqar$dispute_court <- as.numeric(anqar$Q312=="To an Afghanistan state court", 1,0)
anqar$dispute_court[anqar$Q312=='Refused'] <- NA
anqar$dispute_court[anqar$Q312=="Don't Know"] <- NA
anqar$dispute_court[is.na(anqar$Q312)] <- NA

#### Government Performance #### 

recodr <- function(x){ 
  
  x <- as.character(x)
  x[x=="Very well"] <- 5
  x[x=="A little well"] <- 4
  x[x=="Neither poorly, nor well"] <- 3
  x[x=="A little poorly"] <- 2
  x[x=="Very poorly"] <- 1
  x <- ifelse(x>0, as.numeric(x), NA)
}

anqar$prov_perform_security <- recodr(x = anqar$Q202)
anqar$prov_perform_econ <- recodr(anqar$Q203)
anqar$perform_perform_dev <- recodr(anqar$Q204)
anqar$prov_perform_corrupt <- recodr(anqar$Q205)
anqar$prov_perform_overall <- recodr(anqar$Q206)

anqar$perform_overall <- recodr(anqar$Q189)
anqar$perform_security <- recodr(anqar$Q190)
anqar$perform_econ <- recodr(anqar$Q191)
anqar$perform_construct <- recodr(anqar$Q192)
anqar$perform_corrupt <- recodr(anqar$Q193)

anqar$dis_perform_overall <- recodr(anqar$Q195)
anqar$dis_perform_security <- recodr(anqar$Q196)
anqar$dis_perform_econ <- recodr(anqar$Q197)
anqar$dis_perform_construct <- recodr(anqar$Q198)
anqar$dis_perform_corrupt <- recodr(anqar$Q199)

#### Respondend ID ##### 

anqar$respond_id <- row.names(anqar)

anqar_pc_df <- anqar[ ,c(5, 790, 799:814)]

na_code = function(x){
  ifelse(is.na(x) == T, 1, 0)
}

look = na_code(anqar_pc_df)
anqar_pc_df$sum_NA = as.numeric(rowSums(look)>0, 1,0)

anqar_pc_df = anqar_pc_df %>% 
  group_by(year, DISTID) %>% 
  summarise(sum_NA = mean(sum_NA))

anqar_pc_df = anqar_pc_df %>% 
  group_by(DISTID, year) %>% 
  summarise(mean_NA_index = mean(sum_NA, na.rm = T))

anqar$return_NA = na_code(anqar$return_good)
anqar$dispute_NA = na_code(anqar$dispute_court)

anqar_gt = anqar %>% 
  filter(Wave >= 6) %>% 
  group_by(year, DISTID) %>% 
  summarise(return_NA = mean(return_NA, na.rm = T), 
            dispute_NA = mean(dispute_NA, na.rm = T), 
            influence_NA = mean(influence_NA, na.rm = T)
            )

anqar_df = merge(anqar_pc_df, anqar_gt, 
                    by = c('DISTID', 'year'), 
                    all.x = T)

#### court na #### 
df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )

df = merge(df, anqar_df, by = c('DISTID', 'year'), 
           all.x = T)

df = df %>% 
  filter(year >= 2009) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )  %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(dispute_NA)) %>% 
  filter(is.na(na_ever) == F) %>% 
  as.data.frame()

m_NA_court = tjbal(data = df, Y = 'dispute_NA', 
                             D = "treat", 
                             index = c("DISTID", "year"), 
                             demean = F, estimator = "mean", 
                             vce = "jackknife")

#### return na #### 
df <- readRDS('DATA/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )

df = merge(df, anqar_df, by = c('DISTID', 'year'), 
           all.x = T)

df = df %>% 
  filter(year >= 2009) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )  %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(return_NA)) %>% 
  filter(is.na(na_ever) == F) %>% 
  as.data.frame()

m_NA_return = tjbal(data = df, Y = 'return_NA', 
                   D = "treat", 
                   index = c("DISTID", "year"), 
                   demean = F, estimator = "mean", 
                   vce = "jackknife")

#### gov na #### 

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )

df = merge(df, anqar_df, by = c('DISTID', 'year'), 
           all.x = T)

df = df %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )  %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(mean_NA_index)) %>% 
  filter(is.na(na_ever) == F) %>% 
  as.data.frame()

m_NA_gov = tjbal(data = df, Y = 'mean_NA_index', 
                    D = "treat", 
                    index = c("DISTID", "year"), 
                    demean = F, estimator = "mean", 
                    vce = "jackknife")

#### influence na #### 

df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year > 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )

df = merge(df, anqar_df, by = c('DISTID', 'year'), 
           all.x = T)

df = df %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  )  %>% 
  group_by(DISTID) %>% 
  mutate(na_ever = mean(influence_NA)) %>% 
  filter(is.na(na_ever) == F) %>% 
  as.data.frame()

m_NA_inf = tjbal(data = df, Y = 'influence_NA', 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "jackknife")

outcome_table = cbind.data.frame(
  'State Court' =  print(m_NA_court)[c(1,2,6)],
  'Taliban Approval' =  print(m_NA_return)[c(1,2,6)],
  'Gov. Influence' =  print(m_NA_inf)[c(1,2,6)],
  'Gov. Index' = print(m_NA_gov)[c(1,2,6)]
)

outcome_table = rbind.data.frame(outcome_table, 
                                 'N. District' = c('167', '167', '192', '187'),
                                 'N. Year' = c('6', '6', '6', '7'))

print.xtable(xtable(outcome_table), booktabs = T, include.rownames = F, file="tables/attitude-missing-check.tex")
