pgks <- c('readstata13', 'dplyr', 'ggplot2', 'ggthemes', 
          'tjbal', 'tmap', 'sf', 'ggrepel', 'xtable', 'tidyr', 'lfe')
lapply(pgks, require, character.only = T)